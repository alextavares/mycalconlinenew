'use client';

import React from 'react';

// Basic temporary page component
export default function TempPage() {
  return (
    <div>
      <h1>Temporary Test Page</h1>
      <p>If you see this, the localized routing for this path is working.</p>
    </div>
  );
}
